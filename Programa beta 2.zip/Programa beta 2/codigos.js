document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('dataForm');
    const dataTable = document.getElementById('dataTable')?.getElementsByTagName('tbody')[0];

    let users = JSON.parse(localStorage.getItem('users')) || [];

    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();

            const user = {
                name: document.getElementById('name').value,
                birthdate: document.getElementById('birthdate').value,
                gender: document.getElementById('gender').value,
                phone: document.getElementById('phone').value,
                email: document.getElementById('email').value,
                city: document.getElementById('city').value,
                languages: Array.from(document.getElementById('languages').selectedOptions).map(option => option.value),
                degree: document.getElementById('degree').value,
                occupation: document.getElementById('occupation').value,
                hobby: document.getElementById('hobby').value
            };

            users.push(user);
            localStorage.setItem('users', JSON.stringify(users));
            form.reset();
            alert('Datos guardados correctamente.');
        });
    }

    if (dataTable) {
        function appendRow(user, index) {
            const row = dataTable.insertRow();
            row.insertCell(0).innerText = user.name;
            row.insertCell(1).innerText = user.birthdate;
            row.insertCell(2).innerText = user.gender;
            row.insertCell(3).innerText = user.phone;
            row.insertCell(4).innerText = user.email;
            row.insertCell(5).innerText = user.city;
            row.insertCell(6).innerText = user.languages.join(', ');
            row.insertCell(7).innerText = user.degree;
            row.insertCell(8).innerText = user.occupation;
            row.insertCell(9).innerText = user.hobby;
            const actionsCell = row.insertCell(10);

            const editButton = document.createElement('button');
            editButton.innerText = 'Editar';
            editButton.addEventListener('click', () => {
                const index = row.rowIndex - 1; // Adjust for header row
                editRow(index);
            });
            actionsCell.appendChild(editButton);

            const pdfButton = document.createElement('button');
            pdfButton.innerText = 'Descargar PDF';
            pdfButton.addEventListener('click', () => {
                generatePDF(user);
            });
            actionsCell.appendChild(pdfButton);

            const deleteButton = document.createElement('button');
            deleteButton.innerText = 'Eliminar';
            deleteButton.addEventListener('click', () => {
                deleteRow(index);
            });
            actionsCell.appendChild(deleteButton);
        }

        function editRow(index) {
            const user = users[index];
            const name = prompt("Editar Nombre:", user.name);
            const birthdate = prompt("Editar Fecha de Nacimiento:", user.birthdate);
            const gender = prompt("Editar Sexo:", user.gender);
            const phone = prompt("Editar Teléfono:", user.phone);
            const email = prompt("Editar Email:", user.email);
            const city = prompt("Editar Ciudad:", user.city);
            const languages = prompt("Editar Idiomas (separados por comas):", user.languages.join(', ')).split(', ');
            const degree = prompt("Editar Título:", user.degree);
            const occupation = prompt("Editar Ocupación:", user.occupation);
            const hobby = prompt("Editar Hobby:", user.hobby);

            if (name && birthdate && gender && phone && email && city && languages && degree && occupation && hobby) {
                users[index] = { name, birthdate, gender, phone, email, city, languages, degree, occupation, hobby };
                localStorage.setItem('users', JSON.stringify(users));

                dataTable.rows[index].cells[0].innerText = name;
                dataTable.rows[index].cells[1].innerText = birthdate;
                dataTable.rows[index].cells[2].innerText = gender;
                dataTable.rows[index].cells[3].innerText = phone;
                dataTable.rows[index].cells[4].innerText = email;
                dataTable.rows[index].cells[5].innerText = city;
                dataTable.rows[index].cells[6].innerText = languages.join(', ');
                dataTable.rows[index].cells[7].innerText = degree;
                dataTable.rows[index].cells[8].innerText = occupation;
                dataTable.rows[index].cells[9].innerText = hobby;
            }
        }

        function deleteRow(index) {
            users.splice(index, 1);
            localStorage.setItem('users', JSON.stringify(users));
            dataTable.deleteRow(index);
        }

        function generatePDF(user) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            doc.setFont('Century');

            doc.text(15, 20, `${user.name}`);
            doc.text(15, 25, `----------------------------------------------------------------------------------------------`);
            doc.text(15, 35, `* Edad: ${calculateAge(user.birthdate)} años.     |   Fecha de Nacimiento: ${user.birthdate}`);
            doc.text(15, 42, `* Sexo: ${user.gender}.`);
            doc.text(15, 49, `* Teléfono: ${user.phone}.`);
            doc.text(15, 56, `* Email: ${user.email}.`);
            doc.text(15, 63, `* Ciudad: ${user.city}.`);
            doc.text(15, 70, `----------------------------------------------------------------------------------------------`);
            doc.text(15, 77, `¿Qué idioma hablas?`);
            doc.text(15, 84, `   ${user.languages.join(', ')}`);
            doc.text(15, 91, `¿Título adquirido?`);
            doc.text(15, 98, `  ${user.degree}`);
            doc.text(15, 105, `¿Cúal es tú ocupacion? ${user.occupation}`);
            doc.text(15, 112, `  ${user.occupation}`);
            doc.text(15, 119, `¿Cual es tu hobby?`);
            doc.text(15, 126, `  ${user.hobby}`);

            doc.save(`Curriculum vitae de ${user.name}.pdf`);
        }

        function calculateAge(birthdate) {
            const birthDate = new Date(birthdate);
            const ageDifMs = Date.now() - birthDate.getTime();
            const ageDate = new Date(ageDifMs);
            return Math.abs(ageDate.getUTCFullYear() - 1970);
        }

        users.forEach((user, index) => {
            appendRow(user, index);
        });
    }
});